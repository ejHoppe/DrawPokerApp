package drawpokerapp;

/**
 *
 * @author erichoppe
 */
public class Functions
{    
    /*This class is a Singleton that provides methods that checks for winning 
    hands and methods that rewards winning hands*/
    
    public static boolean isFlush(Card...hand)
    {
        boolean flush = true;
        String suit = hand[0].getSuit();

        for (Card card : hand)
        {
            if (!card.suit.equals(suit))
            {
                flush = false;
            }
        }

        return flush;
    }

    public static boolean isHighStraight(int[] rank)
    {
        return rank[0] == 1 && rank[1] == 10 && rank[2] == 11 &&
                rank[3] == 12 && rank[4] == 13;
    }

    public static boolean isStraight(int[] rank)
    {
        boolean straight = true;
        int pocket = rank[0];

        for (int i = 1; i < rank.length; i++)
        {
            if (rank[i] - pocket != 1)
            {
                straight = false;
                break;
            }
            pocket = rank[i];
        }
        return straight;
    }

    public static boolean isFourKind(int[] rank)
    {
        boolean lower = rank[0] == rank[1]
                && rank[1] == rank[2]
                && rank[2] == rank[3];
        
        boolean upper = rank[1] == rank[2] 
                && rank[2] == rank[3] 
                && rank[3] == rank[4];
        
        return (lower || upper);
    }
    
    public static boolean isFullHouse(int[] rank)
    {
        boolean lower = rank[0] == rank[1] && rank[1] == rank[2] 
                && rank[3] == rank[4] ;
        
        boolean upper = rank[2] == rank[3] && rank[3] == rank[4]
                && rank[0] == rank[1];
        
        return (lower || upper);
    }
    
    public static boolean isThreeKind(int[] rank)
    {
        boolean lower = rank[0] == rank[1] && rank[1] == rank[2];        
        boolean middle = rank[1] == rank[2] && rank[2] == rank[3];        
        boolean upper = rank[2] == rank[3] && rank[3] == rank[4];
        
        return (lower || middle || upper);
    }
    
    public static boolean isTwoPair(int[] rank)
    {
        boolean lower = rank[1] == rank[2] && rank[3] == rank[4];        
        boolean middle = rank[0] == rank[1] && rank[3] == rank[4];       
        boolean upper = rank[0] == rank[1] && rank[2] == rank[3];
        
        return (lower || middle || upper);
    }
    
    public static boolean isOnePair(int[] rank)
    {
        boolean a1 = rank[0] == rank[1] && rank[0] > 10 
                || rank[0] == rank[1] && rank[0] == 1;
        
        boolean a2 = rank[1] == rank[2] && rank[1] > 10;
        boolean a3 = rank[2] == rank[3] && rank[2] > 10;
        boolean a4 = rank[3] == rank[4] && rank[3] > 10;
        
        return(a1 || a2 || a3 || a4);
    }
    
    /**
     * This method sets the value of the prize variable to the royal flush 
     * pay-out based on the bet amount; It then updates the win label to that
     * winning amount and returns the prize variable.
     * @param model - the model class
     * @param bet - the amount of the bet
     * @return - the prize of the respective winning hand
     */
    public static double rewardRoyal(Model model, int bet)
    {
        double prize;

        switch (bet)
        {
            case 1:
                prize = Double.parseDouble(model.lblRoyalScore1.getText());
                break;
            case 2:
                prize = Double.parseDouble(model.lblRoyalScore2.getText());
                break;
            case 3:
                prize = Double.parseDouble(model.lblRoyalScore3.getText());
                break;
            case 4:
                prize = Double.parseDouble(model.lblRoyalScore4.getText());
                break;
            case 5:
                prize = Double.parseDouble(model.lblRoyalScore5.getText());
                break;
            default:
                prize = 0;
        }
        model.lblWin.setText("WIN: " + (int)prize);
        return prize;
    }
    
    /**
     * This method sets the value of the prize variable to the straight flush 
     * pay-out based on the bet amount; It then updates the win label to that
     * winning amount and returns the prize variable.
     * @param model - the model class
     * @param bet - the amount of the bet
     * @return - the prize of the respective winning hand
     */
    public static double rewardStraightFlush(Model model, int bet)
    {
        double prize;

        switch (bet)
        {
            case 1:
                prize = Double.parseDouble(model.lblSFScore1.getText());
                break;
            case 2:
                prize = Double.parseDouble(model.lblSFScore2.getText());
                break;
            case 3:
                prize = Double.parseDouble(model.lblSFScore3.getText());
                break;
            case 4:
                prize = Double.parseDouble(model.lblSFScore4.getText());
                break;
            case 5:
                prize = Double.parseDouble(model.lblSFScore5.getText());
                break;
            default:
                prize = 0;
        }
        model.lblWin.setText("WIN: " + (int)prize);
        return prize;
    }
    
    /**
     * This method sets the value of the prize variable to the four-of-a-kind
     * pay-out based on the bet amount; It then updates the win label to that
     * winning amount and returns the prize variable.
     * @param model - the model class
     * @param bet - the amount of the bet
     * @return - the prize of the respective winning hand
     */
    public static double rewardFourKind(Model model, int bet)
    {
        double prize;

        switch (bet)
        {
            case 1:
                prize = Double.parseDouble(model.lblFourScore1.getText());
                break;
            case 2:
                prize = Double.parseDouble(model.lblFourScore2.getText());
                break;
            case 3:
                prize = Double.parseDouble(model.lblFourScore3.getText());
                break;
            case 4:
                prize = Double.parseDouble(model.lblFourScore4.getText());
                break;
            case 5:
                prize = Double.parseDouble(model.lblFourScore5.getText());
                break;
            default:
                prize = 0;
        }
        model.lblWin.setText("WIN: " + (int)prize);
        return prize;
    }
    
    /**
     * This method sets the value of the prize variable to the full house 
     * pay-out based on the bet amount; It then updates the win label to that
     * winning amount and returns the prize variable.
     * @param model - the model class
     * @param bet - the amount of the bet
     * @return - the prize of the respective winning hand
     */
    public static double rewardFullHouse(Model model, int bet)
    {
        double prize;

        switch (bet)
        {
            case 1:
                prize = Double.parseDouble(model.lblFullScore1.getText());
                break;
            case 2:
                prize = Double.parseDouble(model.lblFullScore2.getText());
                break;
            case 3:
                prize = Double.parseDouble(model.lblFullScore3.getText());
                break;
            case 4:
                prize = Double.parseDouble(model.lblFullScore4.getText());
                break;
            case 5:
                prize = Double.parseDouble(model.lblFullScore5.getText());
                break;
            default:
                prize = 0;
        }
        model.lblWin.setText("WIN: " + (int)prize);
        return prize;
    }
    
    /**
     * This method sets the value of the prize variable to the flush 
     * pay-out based on the bet amount; It then updates the win label to that
     * winning amount and returns the prize variable.
     * @param model - the model class
     * @param bet - the amount of the bet
     * @return - the prize of the respective winning hand
     */
    public static double rewardFlush(Model model, int bet)
    {
        double prize;

        switch (bet)
        {
            case 1:
                prize = Double.parseDouble(model.lblFlushScore1.getText());
                break;
            case 2:
                prize = Double.parseDouble(model.lblFlushScore2.getText());
                break;
            case 3:
                prize = Double.parseDouble(model.lblFlushScore3.getText());
                break;
            case 4:
                prize = Double.parseDouble(model.lblFlushScore4.getText());
                break;
            case 5:
                prize = Double.parseDouble(model.lblFlushScore5.getText());
                break;
            default:
                prize = 0;
        }
        model.lblWin.setText("WIN: " + (int)prize);
        return prize;
    }
    
    /**
     * This method sets the value of the prize variable to the straight 
     * pay-out based on the bet amount; It then updates the win label to that
     * winning amount and returns the prize variable.
     * @param model - the model class
     * @param bet - the amount of the bet
     * @return - the prize of the respective winning hand
     */
    public static double rewardStraight(Model model, int bet)
    {
        double prize;

        switch (bet)
        {
            case 1:
                prize = Double.parseDouble(model.lblStraightScore1.getText());
                break;
            case 2:
                prize = Double.parseDouble(model.lblStraightScore2.getText());
                break;
            case 3:
                prize = Double.parseDouble(model.lblStraightScore3.getText());
                break;
            case 4:
                prize = Double.parseDouble(model.lblStraightScore4.getText());
                break;
            case 5:
                prize = Double.parseDouble(model.lblStraightScore5.getText());
                break;
            default:
                prize = 0;
        }
        model.lblWin.setText("WIN: " + (int)prize);
        return prize;
    }
    
    /**
     * This method sets the value of the prize variable to the three-of-a-kind 
     * pay-out based on the bet amount; It then updates the win label to that
     * winning amount and returns the prize variable.
     * @param model - the model class
     * @param bet - the amount of the bet
     * @return - the prize of the respective winning hand
     */
    public static double rewardThreeKind(Model model, int bet)
    {
        double prize;

        switch (bet)
        {
            case 1:
                prize = Double.parseDouble(model.lblThreeScore1.getText());
                break;
            case 2:
                prize = Double.parseDouble(model.lblThreeScore2.getText());
                break;
            case 3:
                prize = Double.parseDouble(model.lblThreeScore3.getText());
                break;
            case 4:
                prize = Double.parseDouble(model.lblThreeScore4.getText());
                break;
            case 5:
                prize = Double.parseDouble(model.lblThreeScore5.getText());
                break;
            default:
                prize = 0;
        }
        model.lblWin.setText("WIN: " + (int)prize);
        return prize;
    }
    
    /**
     * This method sets the value of the prize variable to the two pair 
     * pay-out based on the bet amount; It then updates the win label to that
     * winning amount and returns the prize variable.
     * @param model - the model class
     * @param bet - the amount of the bet
     * @return - the prize of the respective winning hand
     */
    public static double rewardTwoPair(Model model, int bet)
    {
        double prize;

        switch (bet)
        {
            case 1:
                prize = Double.parseDouble(model.lblTwoScore1.getText());
                break;
            case 2:
                prize = Double.parseDouble(model.lblTwoScore2.getText());
                break;
            case 3:
                prize = Double.parseDouble(model.lblTwoScore3.getText());
                break;
            case 4:
                prize = Double.parseDouble(model.lblTwoScore4.getText());
                break;
            case 5:
                prize = Double.parseDouble(model.lblTwoScore5.getText());
                break;
            default:
                prize = 0;
        }
        model.lblWin.setText("WIN: " + (int)prize);
        return prize;
    }
    
    /**
     * This method sets the value of the prize variable to the one-pair 
     * pay-out based on the bet amount; It then updates the win label to that
     * winning amount and returns the prize variable.
     * @param model - the model class
     * @param bet - the amount of the bet
     * @return - the prize of the respective winning hand
     */
    public static double rewardOnePair(Model model, int bet)
    {
        double prize;

        switch (bet)
        {
            case 1:
                prize = Double.parseDouble(model.lblJackScore1.getText());
                break;
            case 2:
                prize = Double.parseDouble(model.lblJackScore2.getText());
                break;
            case 3:
                prize = Double.parseDouble(model.lblJackScore3.getText());
                break;
            case 4:
                prize = Double.parseDouble(model.lblJackScore4.getText());
                break;
            case 5:
                prize = Double.parseDouble(model.lblJackScore5.getText());
                break;
            default:
                prize = 0;
        }
        model.lblWin.setText("WIN: " + (int)prize);
        return prize;
    }
}
