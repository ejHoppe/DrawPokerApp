package drawpokerapp;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/*
This application implements the model, control, view paradigm with the model
class as the model, Style.css as the view, and control as the control.
*/
/**
 *
 * @author belvasinclair
 */
public class Model extends Application
{
    
    //****a bridge between the model and the controller
    Controller control = new Controller(this);
    
    /*==========================================================================
                            Help Windwow
    ==========================================================================*/
    String text = "SHORTCUT KEYS:\n\t"
            + "Numbers:\n\t\t"
            + "1\t\t\thold card one\n\t\t"
            + "2\t\t\thold card two\n\t\t"
            + "3\t\t\thold card three\n\t\t"
            + "4\t\t\thold card four\n\t\t"
            + "5\t\t\thold card five\n\n\t"
            + "Arrows:\n\t\t"
            + "left arrow \tmove button selection left\n\t\t"
            + "right arrow \tmove button selection right\n\n\t"
            + "Function key:\n\t\t"
            + "Space\t\tclick selected button\n\t\t"
            + "Tab\t\t\tcycle through button selection\n\n"
            + "WINNING HANDS:\n\t"
            + "Royal Flush \t\t 10, J, Q, K, A, all the same suit\n\t"
            + "Straight Flush \t five cards in a sequence, all in the same suit\n\t"
            + "Four of a Kind \t All four cards are the same rank\n\t"
            + "Full House \t\t three of a kind with a pair\n\t"
            + "Flush \t\t\t any five cards, all in the same suit\n\t"
            + "Straight \t\t\t five cards in a sequence, not all in the same suit\n\t"
            + "Three of a Kind \t three cards are the same rank\n\t"
            + "Two Pair \t\t\t two pairs\n\t"
            + "Pair \t\t\t\t two cards of the same rank - Jacks or better";
            
    TextArea keysTA = new TextArea(text);
    /*==========================================================================
                            TOP COMPONENTS
    ==========================================================================*/
    Menu menuFile = new Menu("File");

    MenuBar menuBar = new MenuBar(menuFile);

    MenuItem itemHelp = new MenuItem("Help");
    MenuItem itemExit = new MenuItem("Exit");

    /*==========================================================================
                            MIDDLE COMPONENTS
    ==========================================================================*/
    
    
    //==========WAGER BOARD==========
    
    Label lblRoyal = new Label("ROYAL FLUSH");
    Label lblStraightFlush = new Label("STRAIGHT FLUSH");
    Label lblFourKind = new Label("4 OF A KIND");
    Label lblFullHouse = new Label("FULL HOUSE");
    Label lblFlush = new Label("FLUSH");
    Label lblStraight = new Label("STRAIGHT");
    Label lblThreeKind = new Label("3 OF A KIND");
    Label lblTwoPair = new Label("TWO PAIR");
    Label lblJacks = new Label("JACKS OR BETTER");

    VBox bxCategories = new VBox(
            lblRoyal, lblStraightFlush, lblFourKind, lblFullHouse,
            lblFlush, lblStraight, lblThreeKind, lblTwoPair, lblJacks);

    Label lblRoyalScore1 = new Label("250");
    Label lblSFScore1 = new Label("50");
    Label lblFourScore1 = new Label("25");
    Label lblFullScore1 = new Label("9");
    Label lblFlushScore1 = new Label("6");
    Label lblStraightScore1 = new Label("4");
    Label lblThreeScore1 = new Label("3");
    Label lblTwoScore1 = new Label("2");
    Label lblJackScore1 = new Label("1");

    VBox bxLowestWager = new VBox(
            lblRoyalScore1, lblSFScore1, lblFourScore1, lblFullScore1,
            lblFlushScore1, lblStraightScore1, lblThreeScore1, lblTwoScore1,
            lblJackScore1);

    Label lblRoyalScore2 = new Label("500");
    Label lblSFScore2 = new Label("100");
    Label lblFourScore2 = new Label("50");
    Label lblFullScore2 = new Label("18");
    Label lblFlushScore2 = new Label("12");
    Label lblStraightScore2 = new Label("8");
    Label lblThreeScore2 = new Label("6");
    Label lblTwoScore2 = new Label("4");
    Label lblJackScore2 = new Label("2");

    VBox bxLowWager = new VBox(
            lblRoyalScore2, lblSFScore2, lblFourScore2, lblFullScore2,
            lblFlushScore2, lblStraightScore2, lblThreeScore2, lblTwoScore2,
            lblJackScore2);

    Label lblRoyalScore3 = new Label("750");
    Label lblSFScore3 = new Label("150");
    Label lblFourScore3 = new Label("75");
    Label lblFullScore3 = new Label("27");
    Label lblFlushScore3 = new Label("18");
    Label lblStraightScore3 = new Label("12");
    Label lblThreeScore3 = new Label("9");
    Label lblTwoScore3 = new Label("6");
    Label lblJackScore3 = new Label("3");

    VBox bxMidLowWager = new VBox(
            lblRoyalScore3, lblSFScore3, lblFourScore3, lblFullScore3,
            lblFlushScore3, lblStraightScore3, lblThreeScore3, lblTwoScore3,
            lblJackScore3);

    Label lblRoyalScore4 = new Label("1000");
    Label lblSFScore4 = new Label("200");
    Label lblFourScore4 = new Label("100");
    Label lblFullScore4 = new Label("36");
    Label lblFlushScore4 = new Label("24");
    Label lblStraightScore4 = new Label("16");
    Label lblThreeScore4 = new Label("12");
    Label lblTwoScore4 = new Label("8");
    Label lblJackScore4 = new Label("4");

    VBox bxMidHighWager = new VBox(
            lblRoyalScore4, lblSFScore4, lblFourScore4, lblFullScore4, lblFlushScore4,
            lblStraightScore4, lblThreeScore4, lblTwoScore4, lblJackScore4);

    Label lblRoyalScore5 = new Label("4000");
    Label lblSFScore5 = new Label("250");
    Label lblFourScore5 = new Label("125");
    Label lblFullScore5 = new Label("45");
    Label lblFlushScore5 = new Label("30");
    Label lblStraightScore5 = new Label("20");
    Label lblThreeScore5 = new Label("15");
    Label lblTwoScore5 = new Label("10");
    Label lblJackScore5 = new Label("5");

    VBox bxHighWager = new VBox(
            lblRoyalScore5, lblSFScore5, lblFourScore5, lblFullScore5, lblFlushScore5,
            lblStraightScore5, lblThreeScore5, lblTwoScore5, lblJackScore5);

    HBox bxWager = new HBox(bxCategories, bxLowestWager, bxLowWager, bxMidLowWager,
            bxMidHighWager, bxHighWager);

    //==========HOLD LABELS==========
    
    HBox bxHoldOne = new HBox(new Label("HOLD"));
    HBox bxHoldTwo = new HBox(new Label("HOLD"));
    HBox bxHoldThree = new HBox(new Label("HOLD"));
    HBox bxHoldFour = new HBox(new Label("HOLD"));
    HBox bxHoldFive = new HBox(new Label("HOLD"));

    HBox bxHold
            = new HBox(bxHoldOne, bxHoldTwo, bxHoldThree, bxHoldFour, bxHoldFive);
    
    //==========CARD IMAGES==========
    
    HBox bxCardOne = new HBox(new ImageView(new Image("back.png")));
    HBox bxCardTwo = new HBox(new ImageView(new Image("back.png")));
    HBox bxCardThree = new HBox(new ImageView(new Image("back.png")));
    HBox bxCardFour = new HBox(new ImageView(new Image("back.png")));
    HBox bxCardFive = new HBox(new ImageView(new Image("back.png")));

    HBox bxCard
            = new HBox(bxCardOne, bxCardTwo, bxCardThree, bxCardFour, bxCardFive);
    
    //==========WINNINGS/BET/CREDITS LABELS==========
    
    Label lblWin = new Label("WIN 0");
    HBox bxWin = new HBox(lblWin);

    Label lblBet = new Label("BET 0");
    HBox bxBet = new HBox(lblBet);

    Label lblCredits = new Label("$100.00");
    HBox bxCredits = new HBox(lblCredits);

    HBox bxMoney = new HBox(bxWin, bxBet, bxCredits);

    VBox bxHand = new VBox(bxWager, bxHold, bxCard, bxMoney);

    /*==========================================================================
                            BOTTOM COMPONENTS
    ==========================================================================*/
    Label lblSpeed = new Label("SPEED: 1X");
    HBox bxSpeed = new HBox(lblSpeed);

    Button btnSpeed = new Button("SPEED");
    Button btnBetOne = new Button("BET ONE");
    Button btnBetMax = new Button("BET MAX");
    Button btnDeal = new Button("DEAL");

    HBox bxControl = new HBox(
            bxSpeed, btnSpeed, btnBetOne, btnBetMax, btnDeal);

    @Override
    public void start(Stage primaryStage)
    {
        BorderPane root = new BorderPane();
        
        /*======================================================================
                            HELP WINDOW
        ======================================================================*/
        keysTA.setEditable(false);
        keysTA.setStyle("-fx-font-size: 12pt");
        keysTA.setFocusTraversable(false);
        /*======================================================================
                            TOP COMPONENTS
        ======================================================================*/
        root.setTop(menuBar);

        menuFile.getItems().addAll(itemHelp, itemExit);

        itemHelp.setOnAction(Event ->
        {
            StackPane paneHelp = new StackPane(keysTA);
            Scene sceneSecondary = new Scene(paneHelp, 600, 600);

            Stage stageHelp = new Stage();
            stageHelp.setTitle("Help");
            stageHelp.setScene(sceneSecondary);

            stageHelp.setX(primaryStage.getX());
            stageHelp.setY(primaryStage.getY());
            
            stageHelp.show();
        });

        itemExit.setOnAction(Event ->
        {
            System.exit(0);
        });
        /*======================================================================
                            MIDDLE COMPONENTS
        ======================================================================*/
        root.setCenter(bxHand);

        bxCategories.setId("category");

        bxWager.setId("wagerBox");

        bxLowestWager.setId("wager");
        bxLowWager.setId("wager");
        bxMidLowWager.setId("wager");
        bxMidHighWager.setId("wager");
        bxHighWager.setId("wager");

        bxHold.setId("hold");

        bxHoldOne.setVisible(false);
        bxHoldTwo.setVisible(false);
        bxHoldThree.setVisible(false);
        bxHoldFour.setVisible(false);
        bxHoldFive.setVisible(false);

        bxCardOne.setOnMousePressed(Event ->
        {
            control.handleCardClicked("cardOne");
        });

        bxCardTwo.setOnMousePressed(Event ->
        {
            control.handleCardClicked("cardTwo");
        });

        bxCardThree.setOnMousePressed(Event ->
        {
            control.handleCardClicked("cardThree");
        });

        bxCardFour.setOnMousePressed(Event ->
        {
            control.handleCardClicked("cardFour");
        });

        bxCardFive.setOnMousePressed(Event ->
        {
            control.handleCardClicked("cardFive");
        });

        bxCard.setId("hand");

        bxMoney.setId("money");

        bxWin.setId("win-bet-cash");
        bxBet.setId("win-bet-cash");
        bxCredits.setId("win-bet-cash");

        /*======================================================================
                            BOTTOM COMPONENTS
        ======================================================================*/
        root.setBottom(bxControl);
        bxControl.setId("control");

        lblSpeed.setWrapText(true);
        lblSpeed.setId("speed");

        btnSpeed.setOnAction(Event ->
        {
            Sounds.playHeavyClick();
            control.handleButtonClicked(btnSpeed.getText());
        });

        btnBetOne.setOnAction(Event ->
        {
            Sounds.playHeavyClick();
            control.handleButtonClicked(btnBetOne.getText());
        });

        btnBetMax.setOnAction(Event ->
        {
            Sounds.playHeavyClick();
            control.handleButtonClicked(btnBetMax.getText());
        });

        btnDeal.setOnAction(Event ->
        {
            Sounds.playHeavyClick();
            control.handleButtonClicked(btnDeal.getText());
        });

        /*======================================================================
                            STAGE
        ======================================================================*/
        Scene scene = new Scene(root, 900, 700);

        scene.setOnKeyPressed(Event ->
        {
            control.handleKeyPressed(Event.getCode());
        });

        scene.getStylesheets().add(getClass()
                .getResource("Style.css")
                .toExternalForm());
        
        primaryStage.setTitle("B&E GAMES");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        launch(args);
    }

}
