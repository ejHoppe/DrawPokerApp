package drawpokerapp;

/**
 *
 * @author erichoppe
 */
public class CardDeck
{
    CardList cardList;
    
    /**
     * This class creates a deck of cards: 
     * 0-12 Clubs; 13-25 Diamonds; 26-38 Hearts; 39-51 Spades 
     */
    public CardDeck()
    {
        cardList = new CardList();
        
        for(int i = 0; i < 13; i++)
        {
            cardList.add(new Card("Clubs", i+1, i));
        }
        
        for(int i = 13; i < 26; i++)
        {
            cardList.add(new Card("Diamonds", i-12, i));
        }
        
        for(int i = 26; i < 39; i++)
        {
            cardList.add(new Card("Hearts", i-25, i)); 
        }
        
        for(int i = 39; i < 52; i++)
        {
            cardList.add(new Card("Spades", i-38, i));
        }
    }
    
    @Override
    public String toString()
    {
        String returnMe = "";
        
        for(Card card : cardList)
        {
            returnMe += card.toString() + "\n";
        }
        returnMe += "\n";
        
        return returnMe;
    }
}
