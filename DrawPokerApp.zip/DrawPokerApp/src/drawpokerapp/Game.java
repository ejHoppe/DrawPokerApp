package drawpokerapp;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.util.Duration;

/**
 *
 * @author belvasinclair
 */
public class Game
{

    NumberFormat formatter; //used to format the credits to currency
    List<Integer> discard; //used to avoid duplicate cards

    Model model; //the bridge between this class and the Model class
    CardDeck deck;
    Card card1, card2, card3, card4, card5;

    private int[] rank; //used to calculate winning hands of the five cards 
    private int speed, timer, bet;
    private boolean roundTwo;
    
    /**
     * This class increases the functionality of the controller specific to the
     * game play
     * @param model - used to continue the bridge between the model and this
     * class
     */
    public Game(Model model)
    {
        this.discard = new ArrayList<>();
        formatter = NumberFormat.getCurrencyInstance();
        discard = new ArrayList();

        this.model = model;
        deck = new CardDeck();
        speed = 400;
        roundTwo = false;
    }
    
    public void setDealSpeed()
    {
        switch (speed)
        {
            case 400:
                speed = 250;
                model.lblSpeed.setText("SPEED: 2X");
                break;
            case 250:
                speed = 100;
                model.lblSpeed.setText("SPEED: 3X");
                break;
            case 100:
                speed = 400;
                model.lblSpeed.setText("SPEED: 1X");
                break;
        }
    }
    
    /**
     * This method retrieves the bet rank, sets the card image of each card to
 the back image, resets each hold label to invisible, and resets all of
 winning hand label to its default text, and then calls the dealCards()
 method.
     * @param bet - the bet unit that was set by clicking "BET ONE" or "BET MAX"
     */
    public void dealFirstRound(int bet)
    {
        this.bet = bet;
        resetCardFace();
        resetDiscard();
        resetHold();
        resetTextFill();

        model.btnDeal.setText("DRAW");
        dealCards();
    }

    public void dealSecondRound()
    {
        model.btnDeal.setText("DEAL");
        dealCards();
    }
    
    /**
     * This method creates a TimeLine for each card to be dealt to create a
     * staggered card dealing animation; It then deals five cards to the user;
     * After the cards are dealt, a final TimeLine is created to call 
     * checkWinner().
     */
    private void dealCards()
    {
        timer = 1;
        createTimeLine(model.bxHoldOne, model.bxCardOne, "one");
        createTimeLine(model.bxHoldTwo, model.bxCardTwo, "two");
        createTimeLine(model.bxHoldThree, model.bxCardThree, "three");
        createTimeLine(model.bxHoldFour, model.bxCardFour, "four");
        createTimeLine(model.bxHoldFive, model.bxCardFive, "five");

        Timeline timeline = new Timeline(
                new KeyFrame(Duration.millis(speed * timer), (actionEvent) ->
                {
                    checkWinner();
                    roundTwo = !roundTwo;
                }));

        timeline.play();
    }
    
    /**
     * This method is used to create a TimeLine to deal/replace a card
     * @param holdBox - used to determine if the card is being held
     * @param cardBox - used to replace the card image
     * @param cardNum - used to determine which card is being replaced
     */
    private void createTimeLine(HBox holdBox, HBox cardBox, String cardNum)
    {
        if (!holdBox.isVisible())
        {
            Timeline timeline = new Timeline(
                    new KeyFrame(Duration.millis(speed * timer), (actionEvent) ->
                    {
                        replaceCard(cardBox, cardNum);
                        Sounds.playCardFlip();
                    }));

            timeline.play();
            timer++;
        }
    }

    private void replaceCard(HBox box, String cardNum)
    {
        box.getChildren().clear();

        switch (cardNum)
        {
            case "one":
                card1 = getRandomCard();
                box.getChildren().add(card1.getCardFace());
                break;
            case "two":
                card2 = getRandomCard();
                box.getChildren().add(card2.getCardFace());
                break;
            case "three":
                card3 = getRandomCard();
                box.getChildren().add(card3.getCardFace());
                break;
            case "four":
                card4 = getRandomCard();
                box.getChildren().add(card4.getCardFace());
                break;
            case "five":
                card5 = getRandomCard();
                box.getChildren().add(card5.getCardFace());
                break;
        }
    }
    
    /**
     * This method pulls a random card from the deck array at the index of the 
     * random number produced.
     * @return - a random card from the deck
     */
    private Card getRandomCard()
    {
        return deck.cardList.get(getRandomNumber());
    }

    /**
     * This method produces a random number and checks to see if that number has
     * been used before.
     * @return - the random number between 0 (inclusive) and 52 (exclusive)
     */
    private int getRandomNumber()
    {
        Random rand = new Random();
        boolean duplicate = true;
        int randNum = 0;

        while (duplicate)
        {
            duplicate = false;
            randNum = rand.nextInt(52);
            for (int num : discard)
            {
                if (randNum == num)
                {
                    randNum = rand.nextInt(52);
                    duplicate = true;
                }
            }
        }
        discard.add(randNum);
        return randNum;
    }
    
    /**
     * This method calls checkHand() to see if winning hand exists and then
     * rewards the user based on that winning hand; The prize is 25 cents
     * multiplied by the return on the winning hand; It also plays the coin
     * sound effect.
     */
    private void checkWinner()
    {
        resetTextFill();

        switch (checkHand())
        {
            case "ROYAL FLUSH":
                model.lblRoyal.setStyle("-fx-text-fill: blue");

                if (roundTwo)
                {
                    double prize = 0.25 * Functions.rewardRoyal(model, bet);
                    handleWinnings(prize);
                } else
                {
                    Sounds.playCoin();
                }
                break;
            case "STRAIGHT FLUSH":
                model.lblStraightFlush.setStyle("-fx-text-fill: blue");

                if (roundTwo)
                {
                    double prize = 0.25 * Functions.rewardStraightFlush(model, bet);
                    handleWinnings(prize);
                } else
                {
                    Sounds.playCoin();
                }
                break;
            case "4 OF A KIND":
                model.lblFourKind.setStyle("-fx-text-fill: blue");

                if (roundTwo)
                {
                    double prize = 0.25 * Functions.rewardFourKind(model, bet);
                    handleWinnings(prize);
                } else
                {
                    Sounds.playCoin();
                }
                break;
            case "FULL HOUSE":
                model.lblFullHouse.setStyle("-fx-text-fill: blue");

                if (roundTwo)
                {
                    double prize = 0.25 * Functions.rewardFullHouse(model, bet);
                    handleWinnings(prize);
                } else
                {
                    Sounds.playCoin();
                }
                break;
            case "FLUSH":
                model.lblFlush.setStyle("-fx-text-fill: blue");

                if (roundTwo)
                {
                    double prize = 0.25 * Functions.rewardFlush(model, bet);
                    handleWinnings(prize);
                } else
                {
                    Sounds.playCoin();
                }
                break;
            case "STRAIGHT":
                model.lblStraight.setStyle("-fx-text-fill: blue");

                if (roundTwo)
                {
                    double prize = 0.25 * Functions.rewardStraight(model, bet);
                    handleWinnings(prize);
                } else
                {
                    Sounds.playCoin();
                }
                break;
            case "3 OF A KIND":
                model.lblThreeKind.setStyle("-fx-text-fill: blue");

                if (roundTwo)
                {
                    double prize = 0.25 * Functions.rewardThreeKind(model, bet);
                    handleWinnings(prize);
                } else
                {
                    Sounds.playCoin();
                }
                break;
            case "TWO PAIR":
                model.lblTwoPair.setStyle("-fx-text-fill: blue");

                if (roundTwo)
                {
                    double prize = 0.25 * Functions.rewardTwoPair(model, bet);
                    handleWinnings(prize);
                } else
                {
                    Sounds.playCoin();
                }
                break;
            case "ONE PAIR":
                model.lblJacks.setStyle("-fx-text-fill: blue");

                if (roundTwo)
                {
                    double prize = 0.25 * Functions.rewardOnePair(model, bet);
                    handleWinnings(prize);
                } else
                {
                    Sounds.playCoin();
                }
        }
    }
    
    /**
     * This method retrieves the current amount of credits the user has and adds
     * the prize amount to those credits; It also plays the cash register sound
     * effect.
     * @param prize - the winning prize from the respective poker hand
     */
    private void handleWinnings(double prize)
    {
        String creditString = model.lblCredits.getText();
        double credit = Double.parseDouble(creditString.substring(1));
        double nuAmount = credit + prize;
        
        model.lblCredits.setText(formatter.format(nuAmount));
        Sounds.playCashRegister();
    }
    
    /**
     * This method examines the suit and rank of the five cards in the hand to
     * determine if a winning hand exists.
     * @return - the winning poker hand type
     */
    private String checkHand()
    {
        populateRankArray();

        String pokerHand = "";
        if (Functions.isHighStraight(rank)
                && Functions.isFlush(card1, card2, card3, card4, card5))
        {
            pokerHand = "ROYAL FLUSH";
        } else if (Functions.isStraight(rank)
                && Functions.isFlush(card1, card2, card3, card4, card5))
        {
            pokerHand = "STRAIGHT FLUSH";
        } else if (Functions.isFourKind(rank))
        {
            pokerHand = "4 OF A KIND";
        } else if (Functions.isFullHouse(rank))
        {
            pokerHand = "FULL HOUSE";
        } else if (Functions.isFlush(card1, card2, card3, card4, card5))
        {
            pokerHand = "FLUSH";
        } else if (Functions.isStraight(rank) || Functions.isHighStraight(rank))
        {
            pokerHand = "STRAIGHT";
        } else if (Functions.isThreeKind(rank))
        {
            pokerHand = "3 OF A KIND";
        } else if (Functions.isTwoPair(rank))
        {
            pokerHand = "TWO PAIR";
        } else if (Functions.isOnePair(rank))
        {
            pokerHand = "ONE PAIR";
        }
        
        return pokerHand;
    }
    
    /**
     * This method retrieves the rank of each of the five cards and populates
     * the rank array.
     */
    private void populateRankArray()
    {
        rank = new int[5]; //size of hand

        rank[0] = card1.getRank();
        rank[1] = card2.getRank();
        rank[2] = card3.getRank();
        rank[3] = card4.getRank();
        rank[4] = card5.getRank();

        Arrays.sort(rank);
    }

    /**
     * This method clears the current images of the dealt five cards and then
     * replaces them with the images of the card back image.
     */
    private void resetCardFace()
    {
        model.bxCardOne.getChildren().clear();
        model.bxCardTwo.getChildren().clear();
        model.bxCardThree.getChildren().clear();
        model.bxCardFour.getChildren().clear();
        model.bxCardFive.getChildren().clear();

        model.bxCardOne.getChildren().add(new ImageView(new Image("back.png")));
        model.bxCardTwo.getChildren().add(new ImageView(new Image("back.png")));
        model.bxCardThree.getChildren().add(new ImageView(new Image("back.png")));
        model.bxCardFour.getChildren().add(new ImageView(new Image("back.png")));
        model.bxCardFive.getChildren().add(new ImageView(new Image("back.png")));
    }

    private void resetDiscard()
    {
        if (discard.size() > 0)
        {
            discard.clear();
        }
    }

    private void resetHold()
    {
        model.bxHoldOne.setVisible(false);
        model.bxHoldTwo.setVisible(false);
        model.bxHoldThree.setVisible(false);
        model.bxHoldFour.setVisible(false);
        model.bxHoldFive.setVisible(false);
    }

    private void resetTextFill()
    {
        model.lblRoyal.setStyle("-fx-text-fill: ghostwhite");
        model.lblStraightFlush.setStyle("-fx-text-fill: ghostwhite");
        model.lblFourKind.setStyle("-fx-text-fill: ghostwhite");
        model.lblFullHouse.setStyle("-fx-text-fill: ghostwhite");
        model.lblFlush.setStyle("-fx-text-fill: ghostwhite");
        model.lblStraight.setStyle("-fx-text-fill: ghostwhite");
        model.lblThreeKind.setStyle("-fx-text-fill: ghostwhite");
        model.lblTwoPair.setStyle("-fx-text-fill: ghostwhite");
        model.lblJacks.setStyle("-fx-text-fill: ghostwhite");
    }

    @Override
    public String toString()
    {
        String returnMe = "==========Poker Hand===========\n";

        returnMe += "Suit: " + card1.suit + "\t" + "rank: " + card1.rank + "\n";
        returnMe += "Suit: " + card2.suit + "\t" + "rank: " + card2.rank + "\n";
        returnMe += "Suit: " + card3.suit + "\t" + "rank: " + card3.rank + "\n";
        returnMe += "Suit: " + card4.suit + "\t" + "rank: " + card4.rank + "\n";
        returnMe += "Suit: " + card5.suit + "\t" + "rank: " + card5.rank + "\n";

        return returnMe;
    }
}
