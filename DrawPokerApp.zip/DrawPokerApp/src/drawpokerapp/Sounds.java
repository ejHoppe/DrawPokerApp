package drawpokerapp;

import java.io.File;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

/**
 *
 * @author belvasinclair
 */
public class Sounds
{
    //This class is a Singleton that only provides sound effect functionality
    
    public static void playBeep()
    {
        String musicFile = "./sounds/beep.m4a";
        
        Media sound = new Media(new File(musicFile).toURI().toString());
        MediaPlayer mediaPlayer = new MediaPlayer(sound);
        mediaPlayer.play();
    }
    
    public static void playLightClick()
    {
        String musicFile = "./sounds/click1.wav";
        
        Media sound = new Media(new File(musicFile).toURI().toString());
        MediaPlayer mediaPlayer = new MediaPlayer(sound);
        mediaPlayer.play();
    }
    
    public static void playHeavyClick()
    {
        String musicFile = "./sounds/click2.wav";
        
        Media sound = new Media(new File(musicFile).toURI().toString());
        MediaPlayer mediaPlayer = new MediaPlayer(sound);
        mediaPlayer.play();
    }
    
    public static void playCardFlip()
    {
        String musicFile = "./sounds/card_flip.wav";
        
        Media sound = new Media(new File(musicFile).toURI().toString());
        MediaPlayer mediaPlayer = new MediaPlayer(sound);
        mediaPlayer.play();
    }
    
    public static void playCashRegister()
    {
        String musicFile = "./sounds/Cha_Ching_Register.mp3";
        
        Media sound = new Media(new File(musicFile).toURI().toString());
        MediaPlayer mediaPlayer = new MediaPlayer(sound);
        mediaPlayer.play();
    }
    
    public static void playCoin()
    {
        String musicFile = "./sounds/retro_coin.wav";
        
        Media sound = new Media(new File(musicFile).toURI().toString());
        MediaPlayer mediaPlayer = new MediaPlayer(sound);
        mediaPlayer.play();
    }
}
