package drawpokerapp;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/**
 *
 * @author erichoppe
 */
public class Card
{
    protected Image image;
    protected String suit;
    protected int rank;
    protected int index;

    ImageView cardFace;
    
    /**
     * This Class provides the template for each card with setters in the
     * constructor and the respective getter methods below.
     * @param suit - the suit of the card
     * @param rank - the rank of each card
     * @param index - the index in the deck
     */
    public Card(String suit, int rank, int index)
    {
        this.suit = suit;
        this.rank = rank;
        this.index = index;
    }

    public String getSuit()
    {
        return suit;
    }

    public int getRank()
    {
        return rank;
    }

    public int getIndex()
    {
        return index;
    }
    
    /**
     * This method provide a card image respective to the card's index in the
     * deck.
     * @return the imageView of the image respective card
     */
    public ImageView getCardFace()
    {
        switch (index)
        {
            case 0:
                image = new Image("AC.jpg");
                break;
            case 1:
                image = new Image("2C.jpg");
                break;
            case 2:
                image = new Image("3C.jpg");
                break;
            case 3:
                image = new Image("4C.jpg");
                break;
            case 4:
                image = new Image("5C.jpg");
                break;
            case 5:
                image = new Image("6C.jpg");
                break;
            case 6:
                image = new Image("7C.jpg");
                break;
            case 7:
                image = new Image("8C.jpg");
                break;
            case 8:
                image = new Image("9C.jpg");
                break;
            case 9:
                image = new Image("10C.jpg");
                break;
            case 10:
                image = new Image("JC.jpg");
                break;
            case 11:
                image = new Image("QC.jpg");
                break;
            case 12:
                image = new Image("KC.jpg");
                break;
            case 13:
                image = new Image("AD.jpg");
                break;
            case 14:
                image = new Image("2D.jpg");
                break;
            case 15:
                image = new Image("3D.jpg");
                break;
            case 16:
                image = new Image("4D.jpg");
                break;
            case 17:
                image = new Image("5D.jpg");
                break;
            case 18:
                image = new Image("6D.jpg");
                break;
            case 19:
                image = new Image("7D.jpg");
                break;
            case 20:
                image = new Image("8D.jpg");
                break;
            case 21:
                image = new Image("9D.jpg");
                break;
            case 22:
                image = new Image("10D.jpg");
                break;
            case 23:
                image = new Image("JD.jpg");
                break;
            case 24:
                image = new Image("QD.jpg");
                break;
            case 25:
                image = new Image("KD.jpg");
                break;
            case 26:
                image = new Image("AH.jpg");
                break;
            case 27:
                image = new Image("2H.jpg");
                break;
            case 28:
                image = new Image("3H.jpg");
                break;
            case 29:
                image = new Image("4H.jpg");
                break;
            case 30:
                image = new Image("5H.jpg");
                break;
            case 31:
                image = new Image("6H.jpg");
                break;
            case 32:
                image = new Image("7H.jpg");
                break;
            case 33:
                image = new Image("8H.jpg");
                break;
            case 34:
                image = new Image("9H.jpg");
                break;
            case 35:
                image = new Image("10H.jpg");
                break;
            case 36:
                image = new Image("JH.jpg");
                break;
            case 37:
                image = new Image("QH.jpg");
                break;
            case 38:
                image = new Image("KH.jpg");
                break;
            case 39:
                image = new Image("AS.jpg");
                break;
            case 40:
                image = new Image("2S.jpg");
                break;
            case 41:
                image = new Image("3S.jpg");
                break;
            case 42:
                image = new Image("4S.jpg");
                break;
            case 43:
                image = new Image("5S.jpg");
                break;
            case 44:
                image = new Image("6S.jpg");
                break;
            case 45:
                image = new Image("7S.jpg");
                break;
            case 46:
                image = new Image("8S.jpg");
                break;
            case 47:
                image = new Image("9S.jpg");
                break;
            case 48:
                image = new Image("10S.jpg");
                break;
            case 49:
                image = new Image("JS.jpg");
                break;
            case 50:
                image = new Image("QS.jpg");
                break;
            case 51:
                image = new Image("KS.jpg");
                break;
        }
        return new ImageView(image);
    }

    @Override
    public String toString()
    {
        return "Suit: " + suit + "\t" + "Value: " + rank + "\t"
                + "Index: " + index;
    }
}
