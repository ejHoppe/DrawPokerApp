package drawpokerapp;

import java.text.NumberFormat;
import javafx.scene.input.KeyCode;

/**
 *
 * @author belvasinclair
 */
public class Controller
{

    NumberFormat formatter;

    Model model;
    Game game;

    private String creditString;
    private int bet;
    private double credit;
    
    /**
     * 
     * @param model - used to create a bridge between the model and controller 
     */
    public Controller(Model model)
    {
        formatter = NumberFormat.getCurrencyInstance();

        this.model = model;
        game = new Game(model);

        bet = 0; //used to track the lblBet category
    }
    
    /**
     * This method toggles the setVisible() property to the hold label 
     * respective to the numerical-key press.
     * @param kc - the key code of the key press
     */
    public void handleKeyPressed(KeyCode kc)
    {
        if (model.btnDeal.getText().equals("DRAW"))
        {
            Sounds.playLightClick();

            if (kc == kc.DIGIT1)
            {
                model.bxHoldOne.setVisible(!model.bxHoldOne.isVisible());
            }

            if (kc == kc.DIGIT2)
            {
                model.bxHoldTwo.setVisible(!model.bxHoldTwo.isVisible());
            }

            if (kc == kc.DIGIT3)
            {
                model.bxHoldThree.setVisible(!model.bxHoldThree.isVisible());
            }

            if (kc == kc.DIGIT4)
            {
                model.bxHoldFour.setVisible(!model.bxHoldFour.isVisible());
            }

            if (kc == kc.DIGIT5)
            {
                model.bxHoldFive.setVisible(!model.bxHoldFive.isVisible());
            }
        } 
        
    }
    
    /**
     * This method toggles the setVisible() property to the hold label
     * respective to the card clicked.
     * @param card - the string version of the card clicked
     */
    public void handleCardClicked(String card)
    {
        if (model.btnDeal.getText().equals("DRAW"))
        {
            Sounds.playLightClick();

            switch (card)
            {
                case "cardOne":
                    model.bxHoldOne.setVisible(!model.bxHoldOne.isVisible());
                    break;
                case "cardTwo":
                    model.bxHoldTwo.setVisible(!model.bxHoldTwo.isVisible());
                    break;
                case "cardThree":
                    model.bxHoldThree.setVisible(!model.bxHoldThree.isVisible());
                    break;
                case "cardFour":
                    model.bxHoldFour.setVisible(!model.bxHoldFour.isVisible());
                    break;
                case "cardFive":
                    model.bxHoldFive.setVisible(!model.bxHoldFive.isVisible());
                    break;
            }
        }
    }
    
    /**
     * This method utilizes the text of the button pressed to provide the 
     * appropriate functionality to respective button.
     * @param buttonText - the text of the button
     */
    public void handleButtonClicked(String buttonText)
    {
        switch (buttonText)
        {
            case "SPEED":
                game.setDealSpeed();
                break;
            case "BET ONE":
                if (model.btnDeal.getText().equals("DEAL"))
                {
                    betOne(); //increase bet one unit
                }
                break;
            case "BET MAX":
                if (model.btnDeal.getText().equals("DEAL"))
                {
                    betMax(); //increase bet to max amount
                }
                break;
            case "DEAL":
                
                //parse the credit amount from the credit label
                creditString = model.lblCredits.getText();
                credit = Double.parseDouble(creditString.substring(1));
                
                //if a bet is set and there exists sufficient credits
                if (bet > 0 && credit >= (bet * 0.25))
                {
                    credit = credit - (bet * 0.25);
                    model.lblCredits.setText(formatter.format(credit));

                    game.dealFirstRound(bet);
                }
                break;
            case "DRAW":
                game.dealSecondRound();
                break;
        }

    }
    
    /**
     * This method increases the bet by one unit.
     */
    private void betOne()
    {
        bet++;

        if (bet > 5)
        {
            bet = 1;
        }

        model.lblBet.setText("BET " + bet);
        highLightBet();
    }
    
    /**
     * This method increases the bet to the maximum amount.
     */
    private void betMax()
    {
        bet = 5;
        model.lblBet.setText("BET " + bet);
        highLightBet();
    }
    
    /**
     * This method sets the entire wager box to its default background color and
     * highlights the current bet section.
     */
    private void highLightBet()
    {
        switch (bet)
        {
            case 1:
                paintWagerBoxDefaultColor();
                model.bxLowestWager.setStyle("-fx-background-color: red");
                break;
            case 2:
                paintWagerBoxDefaultColor();
                model.bxLowWager.setStyle("-fx-background-color: red");
                break;
            case 3:
                paintWagerBoxDefaultColor();
                model.bxMidLowWager.setStyle("-fx-background-color: red");
                break;
            case 4:
                paintWagerBoxDefaultColor();
                model.bxMidHighWager.setStyle("-fx-background-color: red");
                break;
            case 5:
                paintWagerBoxDefaultColor();
                model.bxHighWager.setStyle("-fx-background-color: red");
                break;
        }
    }
    
    /**
     * This method is used to set the wagerBox to its default color.
     */
    private void paintWagerBoxDefaultColor()
    {
        model.bxLowestWager.setStyle("-fx-background-color: rgba(0, 78, 56, 0.7)");
        model.bxLowWager.setStyle("-fx-background-color: rgba(0, 78, 56, 0.7)");
        model.bxMidLowWager.setStyle("-fx-background-color: rgba(0, 78, 56, 0.7)");
        model.bxMidHighWager.setStyle("-fx-background-color: rgba(0, 78, 56, 0.7)");
        model.bxHighWager.setStyle("-fx-background-color: rgba(0, 78, 56, 0.7)");
    }

}
