package drawpokerapp;

import java.util.ArrayList;

/**
 *
 * @author erichoppe
 */
public class CardList extends ArrayList<Card>
{
    
}
