package drawpokerapp;

import java.util.ArrayList;

/**
 *
 * @author belvasinclair
 */
public class CardList extends ArrayList<Card>
{
    
}
